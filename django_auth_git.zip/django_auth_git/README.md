# Autenticação Django: cadastro e login

Projeto de exemplo com cadastro, login por sessão, painel protegido e logout usando os recursos nativos do Django.

## Requisitos

- Python 3.10+
- pip

## Instalação (Windows PowerShell)

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
python manage.py migrate
python manage.py runserver
```

Acesse:
- Cadastro: http://127.0.0.1:8000/cadastro/
- Login: http://127.0.0.1:8000/login/
- Painel: http://127.0.0.1:8000/painel/

## Instalação (Linux/macOS)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python manage.py migrate
python manage.py runserver
```

## Enviar para o GitHub

Crie um repositório vazio no GitHub e execute na pasta do projeto:

```bash
git init
git add .
git commit -m "Adiciona autenticação Django"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/SEU-REPOSITORIO.git
git push -u origin main
```

Substitua a URL de exemplo pela URL real do seu repositório.

## Segurança

- O Django armazena senhas com hash por meio de `set_password()`.
- Os formulários POST incluem proteção CSRF.
- O logout aceita apenas POST.
- `DEBUG` e hosts são configuráveis por variáveis de ambiente.
- Antes de produção, configure HTTPS, limite de tentativas de login, e-mail verificado, segredo real e configuração de cookies seguros.
- Este projeto é uma base didática; revise e teste antes de publicar em produção.
