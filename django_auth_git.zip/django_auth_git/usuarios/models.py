# Este projeto utiliza o modelo User padrão do Django.
# Crie um modelo de perfil separado se precisar de campos adicionais.
