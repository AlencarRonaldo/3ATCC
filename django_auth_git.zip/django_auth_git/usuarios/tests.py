from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse


class AutenticacaoTests(TestCase):
    def test_cadastro_valido_cria_usuario(self):
        resposta = self.client.post(
            reverse("cadastro"),
            {
                "username": "testeusuario",
                "email": "teste@example.com",
                "senha": "UmaSenhaForte!2026",
                "confirmar_senha": "UmaSenhaForte!2026",
            },
        )
        self.assertRedirects(resposta, reverse("login_usuario"))
        usuario = User.objects.get(username="testeusuario")
        self.assertTrue(usuario.check_password("UmaSenhaForte!2026"))

    def test_cadastro_rejeita_senhas_diferentes(self):
        resposta = self.client.post(
            reverse("cadastro"),
            {
                "username": "testeusuario",
                "email": "teste@example.com",
                "senha": "UmaSenhaForte!2026",
                "confirmar_senha": "OutraSenhaForte!2026",
            },
        )
        self.assertEqual(resposta.status_code, 200)
        self.assertFalse(User.objects.filter(username="testeusuario").exists())

    def test_login_valido_abre_painel(self):
        User.objects.create_user(
            username="testeusuario",
            email="teste@example.com",
            password="UmaSenhaForte!2026",
        )
        resposta = self.client.post(
            reverse("login_usuario"),
            {"username": "testeusuario", "senha": "UmaSenhaForte!2026"},
        )
        self.assertRedirects(resposta, reverse("painel"))

    def test_painel_exige_login(self):
        resposta = self.client.get(reverse("painel"))
        self.assertRedirects(
            resposta,
            f"{reverse('login_usuario')}?next={reverse('painel')}",
        )
