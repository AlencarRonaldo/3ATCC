from django.urls import path
from . import views

urlpatterns = [
    path("", views.cadastro, name="inicio"),
    path("cadastro/", views.cadastro, name="cadastro"),
    path("login/", views.login_usuario, name="login_usuario"),
    path("painel/", views.painel, name="painel"),
    path("logout/", views.logout_usuario, name="logout_usuario"),
]
