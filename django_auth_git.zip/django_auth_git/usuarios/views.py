from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.views.decorators.http import require_http_methods

from .forms import CadastroForm


@require_http_methods(["GET", "POST"])
def cadastro(request):
    if request.user.is_authenticated:
        return redirect("painel")

    if request.method == "POST":
        form = CadastroForm(request.POST)
        if form.is_valid():
            usuario = form.save(commit=False)
            usuario.email = form.cleaned_data["email"]
            usuario.set_password(form.cleaned_data["senha"])
            usuario.save()
            messages.success(request, "Cadastro realizado! Agora faça login.")
            return redirect("login_usuario")
    else:
        form = CadastroForm()

    return render(request, "usuarios/cadastro.html", {"form": form})


@require_http_methods(["GET", "POST"])
def login_usuario(request):
    if request.user.is_authenticated:
        return redirect("painel")

    if request.method == "POST":
        identificador = request.POST.get("username", "").strip()
        senha = request.POST.get("senha", "")
        usuario = authenticate(
            request,
            username=identificador,
            password=senha,
        )
        if usuario is not None:
            login(request, usuario)
            return redirect("painel")

        messages.error(request, "Usuário ou senha inválidos.")

    return render(request, "usuarios/login.html")


@login_required
def painel(request):
    return render(request, "usuarios/painel.html")


@require_http_methods(["POST"])
@login_required
def logout_usuario(request):
    logout(request)
    messages.success(request, "Você saiu da sua conta.")
    return redirect("login_usuario")
